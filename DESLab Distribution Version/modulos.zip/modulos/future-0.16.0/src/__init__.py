# Make this a package only for the sake of importing
# src.future.__version__ etc. from setup.py
