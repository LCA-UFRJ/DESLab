# coding=utf-8
""" FAdo initialization"""
version="1.0"
__all__=["fa","reex","common","cfg","grail","fl","comboperations","rndfa"]
__package__="FAdo"
